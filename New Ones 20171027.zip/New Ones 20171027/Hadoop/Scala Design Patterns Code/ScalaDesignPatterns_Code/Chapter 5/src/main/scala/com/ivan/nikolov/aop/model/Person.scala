package com.ivan.nikolov.aop.model

case class Person(firstName: String, lastName: String, age: Int)
