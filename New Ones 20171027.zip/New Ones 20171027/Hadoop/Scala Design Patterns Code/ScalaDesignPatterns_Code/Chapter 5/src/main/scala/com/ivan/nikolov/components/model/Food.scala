package com.ivan.nikolov.components.model

case class Food(name: String)
