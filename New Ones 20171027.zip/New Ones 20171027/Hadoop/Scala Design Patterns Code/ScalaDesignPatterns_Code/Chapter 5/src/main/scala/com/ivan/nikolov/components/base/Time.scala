package com.ivan.nikolov.components.base

trait Time {
  def getTime(): String
}
