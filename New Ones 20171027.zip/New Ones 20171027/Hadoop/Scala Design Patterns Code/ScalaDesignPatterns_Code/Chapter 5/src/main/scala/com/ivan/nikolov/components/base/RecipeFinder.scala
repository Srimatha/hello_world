package com.ivan.nikolov.components.base

trait RecipeFinder {
  def findRecipe(dish: String): String
}
