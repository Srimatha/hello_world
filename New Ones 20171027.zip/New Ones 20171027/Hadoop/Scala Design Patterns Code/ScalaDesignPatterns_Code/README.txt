You will need to install an IDE that supports the Scala programming language (IntelliJ IDEA or Eclipse), even though a text editor also works well to read the code. 
You will need to have Maven and Scala (not 100% required as Maven will take care of downloading Scala for the purposes of compilation).

The examples in the book were written and tested on a Unix-based operating system;
however, they should also successfully compile and run on Windows.