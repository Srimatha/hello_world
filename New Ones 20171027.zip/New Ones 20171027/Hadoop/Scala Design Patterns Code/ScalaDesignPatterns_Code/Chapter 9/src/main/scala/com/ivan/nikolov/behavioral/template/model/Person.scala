package com.ivan.nikolov.behavioral.template.model

case class Person(name: String, age: Int, address: String)
