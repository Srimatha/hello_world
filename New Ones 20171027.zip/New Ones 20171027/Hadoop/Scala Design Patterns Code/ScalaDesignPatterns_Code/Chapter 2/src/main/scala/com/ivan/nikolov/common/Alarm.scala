package com.ivan.nikolov.common

trait Alarm {
  def trigger(): String
}
