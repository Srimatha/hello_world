package com.ivan.nikolov.behavioral.chain_of_responsibility

case class Money(amount: Int)
