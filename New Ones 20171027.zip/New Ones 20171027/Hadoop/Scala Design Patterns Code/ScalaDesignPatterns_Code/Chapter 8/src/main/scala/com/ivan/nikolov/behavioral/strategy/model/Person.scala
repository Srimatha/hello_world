package com.ivan.nikolov.behavioral.strategy.model

case class Person(name: String, age: Int, address: String)
