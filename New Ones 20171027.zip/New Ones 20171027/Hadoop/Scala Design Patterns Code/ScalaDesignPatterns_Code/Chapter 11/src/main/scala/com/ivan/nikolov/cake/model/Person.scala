package com.ivan.nikolov.cake.model

case class Person(id: Int, name: String, age: Int)
