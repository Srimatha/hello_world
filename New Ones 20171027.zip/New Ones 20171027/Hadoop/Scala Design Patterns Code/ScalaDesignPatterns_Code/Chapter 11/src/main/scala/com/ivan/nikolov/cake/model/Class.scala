package com.ivan.nikolov.cake.model

case class Class(id: Int, name: String)
