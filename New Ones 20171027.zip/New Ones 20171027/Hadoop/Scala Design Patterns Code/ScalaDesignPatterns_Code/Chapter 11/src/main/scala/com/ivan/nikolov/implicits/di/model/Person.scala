package com.ivan.nikolov.implicits.di.model

case class Person(name: String, age: Int)
