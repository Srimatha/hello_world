package com.ivan.nikolov.pimp.model

case class Person(name: String, age: Int)
