package com.ivan.nikolov.structural.facade.model

case class Person(name: String, age: Int)
