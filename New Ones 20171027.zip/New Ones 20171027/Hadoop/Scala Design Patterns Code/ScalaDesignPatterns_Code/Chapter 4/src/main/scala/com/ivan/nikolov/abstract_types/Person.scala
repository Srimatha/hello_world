package com.ivan.nikolov.abstract_types


case class Person(name: String)
