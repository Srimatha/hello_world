
--split-by : It is used to specify the column of the table used to generate splits for imports. This means that it specifies which column will be used to create the split while importing the data into your cluster. It can be used to enhance the import performance by achieving greater parallelism. Sqoop creates splits based on values in a particular column of the table which is specified by --split-by by the user through the import command. If it is not available, the primary key of the input table is used to create the splits.

Reason to use : Sometimes the primary key doesn't have an even distribution of values between the min and max values(which is used to create the splits if --split-by is not available). In such a situation you can specify some other column which has proper distribution of data to create splits for efficient imports.

--boundary-query : By default sqoop will use query select min(), max() from to find out boundaries for creating splits. In some cases this query is not the most optimal so you can specify any arbitrary query returning two numeric columns using --boundary-query argument.

Reason to use : If --split-by is not giving you the optimal performance you can use this to improve the performance further.
1. Login to Hadoop environment

2.
ClusterShell
nodeset --version
Ensure it is version 1.7.3 or later

3.
Copy a Table from Teradata to Hadoop
sqoop import \
--connect jdbc:"teradata://tercoddb.edw.health/LOGMECH=LDAP,Database=EDW_DEV_SNP_PBD_P40135_DB" \
--username tadive -P \
--table PBSOL_ATH_RFRNC_QSTN_DTL_T \
--target-dir /user/tadive/PBSOL_REF_QSTN_table_contents \
--fields-terminated-by , \
--split-by QSTN_CD

4.
Check for Uploaded Files
hdfs dfs -ls

5.
Copy a table to Hive (IMP Note: Before import the Database in Hive should be created. Here the Database name is 'pbsol_ref' )
sqoop import \
--connect jdbc:"teradata://tercoddb.edw.health/LOGMECH=LDAP,Database=EDW_DEV_SNP_PBD_P40135_DB" \
--username tadive -P \
--table PBSOL_ATH_RFRNC_ANSWR_DTL_T \
--target-dir /user/tadive/PBSOL_REF_ANSWR_table_contents \
--fields-terminated-by , \
--split-by ANSWR_CD \
--hive-import --create-hive-table --hive-table pbsol_ref.answr





